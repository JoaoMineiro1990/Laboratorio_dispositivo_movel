package com.example.app_movel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
